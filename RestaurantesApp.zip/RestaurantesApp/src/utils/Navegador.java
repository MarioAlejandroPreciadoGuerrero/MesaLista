package utils;

import javax.swing.*;

public class Navegador {

    private static JFrame pantallaActual;

    public static void ir(JFrame destino) {
        if (pantallaActual != null) {
            pantallaActual.dispose();
        }
        pantallaActual = destino;
        destino.setVisible(true);
    }

    public static void volver() {
        if (pantallaActual != null) {
            pantallaActual.dispose();
        }
    }
}

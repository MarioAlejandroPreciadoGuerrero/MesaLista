import views.ListaRestaurantes;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
    ListaRestaurantes ventana = new ListaRestaurantes("Carlos G");
    ventana.setVisible(true);  // ← esto faltaba
});
}
}
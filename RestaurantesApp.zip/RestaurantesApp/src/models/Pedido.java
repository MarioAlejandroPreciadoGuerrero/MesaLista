package models;

import java.util.List;

public class Pedido {
    private String nombreProducto;
    private List<String> ingredientes;
    private int monto;

    public Pedido(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public String getNombreProducto()         { return nombreProducto; }
    public List<String> getIngredientes()     { return ingredientes; }
    public void setIngredientes(List<String> i){ this.ingredientes = i; }
    public int getMonto()                     { return monto; }
    public void setMonto(int monto)           { this.monto = monto; }
}

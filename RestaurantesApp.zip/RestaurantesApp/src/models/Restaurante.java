package models;

public class Restaurante {
    private String nombre;
    private String estado; // "disponible", "poca", "no"

    public Restaurante(String nombre, String estado) {
        this.nombre = nombre;
        this.estado = estado;
    }

    public String getNombre() { return nombre; }
    public String getEstado()  { return estado; }
}

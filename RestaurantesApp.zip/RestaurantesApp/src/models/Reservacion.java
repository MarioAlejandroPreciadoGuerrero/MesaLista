package models;

public class Reservacion {
    private String restaurante;
    private String fecha;
    private int    personas;
    private String area;
    private int    monto;

    public Reservacion(String restaurante) {
        this.restaurante = restaurante;
    }

    public String getRestaurante()         { return restaurante; }
    public String getFecha()               { return fecha; }
    public void   setFecha(String f)       { this.fecha = f; }
    public int    getPersonas()            { return personas; }
    public void   setPersonas(int p)       { this.personas = p; }
    public String getArea()                { return area; }
    public void   setArea(String a)        { this.area = a; }
    public int    getMonto()               { return monto; }
    public void   setMonto(int m)          { this.monto = m; }
}

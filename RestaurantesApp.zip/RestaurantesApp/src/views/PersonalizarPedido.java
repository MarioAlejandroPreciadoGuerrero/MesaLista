package views;

import models.Pedido;
import utils.Navegador;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class PersonalizarPedido extends JFrame {

    private static final Color NARANJA = new Color(249, 115, 22);
    private static final Color FONDO   = new Color(250, 249, 246);

    private final String restaurante;
    private final Pedido pedido;
    private final List<JCheckBox> todosLosChecks = new ArrayList<>();

    private static final String[][] SECCIONES = {
        {
            "Ingrediente Principal",
            "Queso extra", "Tocino", "Jalapeño", "Cebolla caramelizada",
            "Aguacate", "Huevo", "Champiñones", "Chile de árbol"
        },
        {
            "Complemento",
            "Papas fritas", "Aros de cebolla", "Ensalada", "Refresco",
            "Agua mineral", "Jugo natural", "Malteada", "Postre del día"
        }
    };

    public PersonalizarPedido(String restaurante, Pedido pedido) {
        this.restaurante = restaurante;
        this.pedido      = pedido;

        setTitle("Personalizar pedido");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(crearHeader(),  BorderLayout.NORTH);
        add(crearCuerpo(),  BorderLayout.CENTER);
        add(crearFooter(),  BorderLayout.SOUTH);

        setSize(960, 680);
        setLocationRelativeTo(null);
    }

    // ── Header ────────────────────────────────────────────────
    private JPanel crearHeader() {
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(NARANJA);
        header.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));

        JLabel titulo = new JLabel("Personalizar el pedido");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);

        JLabel sub = new JLabel("Elige las opciones disponibles y personaliza la orden");
        sub.setFont(new Font("SansSerif", Font.PLAIN, 15));
        sub.setForeground(new Color(255, 255, 255, 210));

        header.add(titulo);
        header.add(Box.createVerticalStrut(4));
        header.add(sub);
        return header;
    }

    // ── Cuerpo con secciones ──────────────────────────────────
    private JScrollPane crearCuerpo() {
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(FONDO);
        body.setBorder(BorderFactory.createEmptyBorder(20, 32, 20, 32));

        for (String[] seccion : SECCIONES) {
            body.add(crearSeccionHeader(seccion[0]));
            body.add(Box.createVerticalStrut(10));
            body.add(crearGrid(seccion));
            body.add(Box.createVerticalStrut(16));
        }

        JScrollPane scroll = new JScrollPane(body);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        return scroll;
    }

    private JPanel crearSeccionHeader(String titulo) {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        panel.setBackground(NARANJA);
        panel.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        JLabel lbl = new JLabel(titulo);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 14));
        panel.add(lbl, BorderLayout.WEST);
        return panel;
    }

    private JPanel crearGrid(String[] seccion) {
        JPanel grid = new JPanel(new GridLayout(0, 2, 10, 10));
        grid.setBackground(FONDO);
        grid.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

        for (int i = 1; i < seccion.length; i++) {
            grid.add(crearOpcion(seccion[i]));
        }
        return grid;
    }

    private JPanel crearOpcion(String nombre) {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createLineBorder(new Color(229, 224, 216), 1));

        JCheckBox cb = new JCheckBox(nombre);
        cb.setBackground(Color.WHITE);
        cb.setFont(new Font("SansSerif", Font.PLAIN, 14));
        todosLosChecks.add(cb);
        panel.add(cb);
        return panel;
    }

    // ── Footer ────────────────────────────────────────────────
    private JPanel crearFooter() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 14));
        footer.setBackground(FONDO);
        footer.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(229, 224, 216)));

        JButton btnConfirmar = crearBoton("Confirmar");
        btnConfirmar.addActionListener(e -> onConfirmar());

        JButton btnCancelar = crearBoton("Cancelar");
        btnCancelar.addActionListener(e -> {
            ListaRestaurantes lr = new ListaRestaurantes("Carlos G");
            Navegador.ir(lr);
        });

        footer.add(btnConfirmar);
        footer.add(btnCancelar);
        return footer;
    }

    private void onConfirmar() {
        List<String> seleccionados = new ArrayList<>();
        for (JCheckBox cb : todosLosChecks) {
            if (cb.isSelected()) seleccionados.add(cb.getText());
        }
        pedido.setIngredientes(seleccionados);
        pedido.setMonto(100 + seleccionados.size() * 15);

        PreferenciasReservacion pr = new PreferenciasReservacion(restaurante, pedido);
        Navegador.ir(pr);
    }

    private JButton crearBoton(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(NARANJA);
        btn.setForeground(Color.WHITE);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 14));
        btn.setPreferredSize(new Dimension(160, 42));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}

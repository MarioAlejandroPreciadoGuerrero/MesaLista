package views;

import models.Restaurante;
import utils.Navegador;

import javax.swing.*;
import java.awt.*;

public class ListaRestaurantes extends JFrame {

    private static final Color NARANJA = new Color(249, 115, 22);
    private static final Color FONDO   = new Color(250, 249, 246);

    private final Restaurante[] restaurantes = {
        new Restaurante("Rincon el asador", "poca"),
        new Restaurante("El Deshuesadero",  "poca"),
        new Restaurante("Mariscos el rey",  "no"),
    };

    public ListaRestaurantes(String usuario) {
        setTitle("Restaurantes");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(crearHeader(usuario), BorderLayout.NORTH);
        add(crearContenido(),     BorderLayout.CENTER);

        setSize(960, 580);
        setLocationRelativeTo(null);
    }

    // ── Header ────────────────────────────────────────────────
    private JPanel crearHeader(String usuario) {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NARANJA);
        header.setBorder(BorderFactory.createEmptyBorder(12, 24, 12, 24));

        JPanel izq = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        izq.setOpaque(false);

        // Avatar circular
        JPanel avatar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(200, 200, 200));
                g2.fillOval(0, 0, 52, 52);
                g2.setColor(new Color(160, 160, 160));
                g2.fillOval(16, 8, 20, 20);
                g2.fillOval(8, 32, 36, 26);
            }
        };
        avatar.setPreferredSize(new Dimension(52, 52));
        avatar.setOpaque(false);

        JLabel lblNombre = new JLabel(usuario);
        lblNombre.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblNombre.setForeground(Color.WHITE);

        izq.add(avatar);
        izq.add(lblNombre);

        JButton btnMisRes = new JButton("Mis Reservaciones ›");
        btnMisRes.setForeground(Color.WHITE);
        btnMisRes.setBorder(BorderFactory.createLineBorder(new Color(255, 255, 255, 160), 1, true));
        btnMisRes.setContentAreaFilled(false);
        btnMisRes.setFont(new Font("SansSerif", Font.PLAIN, 14));
        btnMisRes.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnMisRes.addActionListener(e ->
            JOptionPane.showMessageDialog(this, "Pantalla 'Mis Reservaciones' próximamente.")
        );

        header.add(izq,       BorderLayout.WEST);
        header.add(btnMisRes, BorderLayout.EAST);
        return header;
    }

    // ── Grid de tarjetas ─────────────────────────────────────
    private JPanel crearContenido() {
        JPanel contenido = new JPanel(new GridLayout(1, restaurantes.length, 28, 0));
        contenido.setBackground(FONDO);
        contenido.setBorder(BorderFactory.createEmptyBorder(40, 40, 48, 40));

        for (Restaurante r : restaurantes) {
            contenido.add(crearTarjeta(r));
        }
        return contenido;
    }

    private JPanel crearTarjeta(Restaurante r) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(FONDO);

        // Imagen placeholder
        JPanel imgPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(180, 170, 160));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                g2.setColor(new Color(140, 130, 120));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 48));
                FontMetrics fm = g2.getFontMetrics();
                String icon = "🍽";
                g2.drawString(icon,
                    (getWidth()  - fm.stringWidth(icon)) / 2,
                    (getHeight() + fm.getAscent()) / 2 - 8
                );
            }
        };
        imgPanel.setPreferredSize(new Dimension(240, 220));
        imgPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));
        imgPanel.setOpaque(false);
        imgPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel lblNombre = new JLabel(r.getNombre(), SwingConstants.CENTER);
        lblNombre.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lblNombre.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel acciones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        acciones.setOpaque(false);
        acciones.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btnRes = crearBoton("Reservaciones");
        btnRes.addActionListener(e -> {
            SeleccionarPedido sp = new SeleccionarPedido(r.getNombre());
            Navegador.ir(sp);
        });

        acciones.add(btnRes);
        acciones.add(crearBadgeEstado(r.getEstado()));

        card.add(imgPanel);
        card.add(Box.createVerticalStrut(10));
        card.add(lblNombre);
        card.add(Box.createVerticalStrut(8));
        card.add(acciones);
        return card;
    }

    // ── Badge disponibilidad ──────────────────────────────────
    private JPanel crearBadgeEstado(String estado) {
        JPanel badge = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        badge.setOpaque(false);

        JPanel dot = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Color c = switch (estado) {
                    case "disponible" -> new Color(34, 197, 94);
                    case "poca"       -> new Color(191, 223, 58);
                    default           -> new Color(239, 68, 68);
                };
                ((Graphics2D) g).setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g.setColor(c);
                g.fillOval(0, 2, 14, 14);
            }
        };
        dot.setPreferredSize(new Dimension(14, 18));
        dot.setOpaque(false);

        String texto = switch (estado) {
            case "disponible" -> "Disponible";
            case "poca"       -> "Poca disponibilidad";
            default           -> "No disponible";
        };
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lbl.setForeground(new Color(80, 80, 80));

        badge.add(dot);
        badge.add(lbl);
        return badge;
    }

    private JButton crearBoton(String texto) {
        JButton btn = new JButton(texto);
        btn.setBackground(NARANJA);
        btn.setForeground(Color.WHITE);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 13));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }
}

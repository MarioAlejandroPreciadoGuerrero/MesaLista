package views;

import models.Pedido;
import utils.Navegador;

import javax.swing.*;
import java.awt.*;

public class SeleccionarPedido extends JFrame {

    private static final Color NARANJA = new Color(249, 115, 22);
    private static final Color FONDO   = new Color(250, 249, 246);

    private final String restaurante;

    private final String[] productos = {
        "Doble Smash Burger",
        "Clásica BBQ",
        "Pollo Crispy",
        "Veggie Burger",
    };

    private JPanel[] tarjetas;
    private int      indiceSeleccionado = -1;

    public SeleccionarPedido(String restaurante) {
        this.restaurante = restaurante;
        setTitle("Selecciona el pedido");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(crearHeader(), BorderLayout.NORTH);
        add(crearContenido(), BorderLayout.CENTER);

        setSize(960, 580);
        setLocationRelativeTo(null);
    }

    // ── Header ────────────────────────────────────────────────
    private JPanel crearHeader() {
        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBackground(NARANJA);
        header.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));

        JLabel titulo = new JLabel("Selecciona el pedido");
        titulo.setFont(new Font("SansSerif", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);

        JLabel sub = new JLabel("Elige las opciones disponibles y personaliza la orden");
        sub.setFont(new Font("SansSerif", Font.PLAIN, 15));
        sub.setForeground(new Color(255, 255, 255, 210));

        header.add(titulo);
        header.add(Box.createVerticalStrut(4));
        header.add(sub);
        return header;
    }

    // ── Grid de productos ─────────────────────────────────────
    private JPanel crearContenido() {
        tarjetas = new JPanel[productos.length];

        JPanel grid = new JPanel(new GridLayout(2, 2, 24, 24));
        grid.setBackground(FONDO);
        grid.setBorder(BorderFactory.createEmptyBorder(32, 40, 32, 40));

        for (int i = 0; i < productos.length; i++) {
            final int idx = i;
            tarjetas[i] = crearTarjeta(productos[i], () -> seleccionar(idx));
            grid.add(tarjetas[i]);
        }
        return grid;
    }

    private JPanel crearTarjeta(String nombre, Runnable alSeleccionar) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createLineBorder(new Color(220, 215, 208), 1));

        // Imagen placeholder
        JPanel img = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(230, 220, 210));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(160, 140, 120));
                g2.setFont(new Font("SansSerif", Font.PLAIN, 64));
                FontMetrics fm = g2.getFontMetrics();
                String ic = "🍔";
                g2.drawString(ic,
                    (getWidth()  - fm.stringWidth(ic)) / 2,
                    (getHeight() + fm.getAscent()) / 2 - 10
                );
            }
        };
        img.setPreferredSize(new Dimension(0, 180));

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setBackground(Color.WHITE);

        JLabel lbl = new JLabel(nombre, SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lbl.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));

        JButton btn = new JButton("Seleccionar");
        btn.setBackground(NARANJA);
        btn.setForeground(Color.WHITE);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 14));
        btn.setPreferredSize(new Dimension(0, 44));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(e -> alSeleccionar.run());

        bottom.add(lbl, BorderLayout.NORTH);
        bottom.add(btn, BorderLayout.SOUTH);

        card.add(img,    BorderLayout.CENTER);
        card.add(bottom, BorderLayout.SOUTH);
        return card;
    }

    // ── Selección ─────────────────────────────────────────────
    private void seleccionar(int idx) {
        indiceSeleccionado = idx;

        for (int i = 0; i < tarjetas.length; i++) {
            boolean sel = (i == idx);
            tarjetas[i].setBorder(BorderFactory.createLineBorder(
                sel ? NARANJA : new Color(220, 215, 208), sel ? 2 : 1
            ));
        }

        // Avanzar tras breve pausa visual
        Timer t = new Timer(250, e -> {
            Pedido pedido = new Pedido(productos[idx]);
            PersonalizarPedido pp = new PersonalizarPedido(restaurante, pedido);
            Navegador.ir(pp);
        });
        t.setRepeats(false);
        t.start();
    }
}

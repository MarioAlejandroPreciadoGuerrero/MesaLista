package views;

import models.Pedido;
import models.Reservacion;
import utils.Navegador;

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class PreferenciasReservacion extends JFrame {

    private static final Color NARANJA = new Color(249, 115, 22);
    private static final Color FONDO   = new Color(250, 249, 246);
    private static final int   PRECIO_BASE = 100;

    private final String restaurante;
    private final Pedido pedido;

    private int    personas = 1;
    private JLabel lblPersonas;
    private JLabel lblMonto;
    private JLabel lblFecha;
    private JTextField txtArea;

    public PreferenciasReservacion(String restaurante, Pedido pedido) {
        this.restaurante = restaurante;
        this.pedido      = pedido;

        setTitle("Preferencias de reservación");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        add(crearHeader(), BorderLayout.NORTH);
        add(crearCuerpo(), BorderLayout.CENTER);

        setSize(680, 460);
        setLocationRelativeTo(null);
        setResizable(false);
    }

    // ── Header ────────────────────────────────────────────────
    private JPanel crearHeader() {
        JPanel header = new JPanel(new FlowLayout(FlowLayout.LEFT));
        header.setBackground(NARANJA);
        header.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        JLabel lbl = new JLabel("Preferencias de reservación:");
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 14));
        lbl.setForeground(Color.WHITE);
        header.add(lbl);
        return header;
    }

    // ── Cuerpo ────────────────────────────────────────────────
    private JPanel crearCuerpo() {
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(FONDO);
        body.setBorder(BorderFactory.createEmptyBorder(20, 28, 24, 28));

        body.add(filaTexto("Restaurante :  " + restaurante));
        body.add(Box.createVerticalStrut(14));
        body.add(crearFilaFecha());
        body.add(Box.createVerticalStrut(14));
        body.add(crearFilaPersonasMonto());
        body.add(Box.createVerticalStrut(14));
        body.add(crearFilaArea());
        body.add(Box.createVerticalStrut(20));

        // Botón Siguiente centrado
        JPanel centerSig = new JPanel(new FlowLayout(FlowLayout.CENTER));
        centerSig.setOpaque(false);
        centerSig.add(crearBoton("Siguiente", e -> onSiguiente()));
        body.add(centerSig);

        body.add(Box.createVerticalStrut(14));

        JSeparator sep = new JSeparator();
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setForeground(new Color(229, 224, 216));
        body.add(sep);
        body.add(Box.createVerticalStrut(14));
        body.add(crearFilaOtraPersona());

        return body;
    }

    private JPanel filaTexto(String texto) {
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        fila.setOpaque(false);
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 15));
        fila.add(lbl);
        return fila;
    }

    private JPanel crearFilaFecha() {
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        fila.setOpaque(false);

        String hoy = new SimpleDateFormat("dd/MM/yyyy hh:mma").format(new Date());
        lblFecha = new JLabel(hoy);
        lblFecha.setFont(new Font("SansSerif", Font.PLAIN, 15));

        JButton btnCal = new JButton("📅");
        btnCal.setBorderPainted(false);
        btnCal.setContentAreaFilled(false);
        btnCal.setFont(new Font("SansSerif", Font.PLAIN, 18));
        btnCal.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCal.addActionListener(e -> abrirSelectorFecha());

        fila.add(new JLabel("Fecha y hora:"));
        fila.add(lblFecha);
        fila.add(btnCal);
        return fila;
    }

    private void abrirSelectorFecha() {
        JSpinner spinner = new JSpinner(new SpinnerDateModel());
        spinner.setEditor(new JSpinner.DateEditor(spinner, "dd/MM/yyyy hh:mma"));
        spinner.setValue(new Date());

        int r = JOptionPane.showConfirmDialog(
            this, spinner, "Selecciona fecha y hora",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE
        );
        if (r == JOptionPane.OK_OPTION) {
            Date d = (Date) spinner.getValue();
            lblFecha.setText(new SimpleDateFormat("dd/MM/yyyy hh:mma").format(d));
        }
    }

    private JPanel crearFilaPersonasMonto() {
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        fila.setOpaque(false);

        lblPersonas = new JLabel("1");
        lblPersonas.setFont(new Font("SansSerif", Font.PLAIN, 15));
        lblMonto = new JLabel(calcularMonto());
        lblMonto.setFont(new Font("SansSerif", Font.PLAIN, 15));

        JButton btnMenos = crearBtnContador("−");
        JButton btnMas   = crearBtnContador("+");
        btnMenos.addActionListener(e -> cambiarPersonas(-1));
        btnMas.addActionListener(e   -> cambiarPersonas(1));

        fila.add(new JLabel("Número de personas:"));
        fila.add(btnMenos);
        fila.add(lblPersonas);
        fila.add(btnMas);
        fila.add(Box.createHorizontalStrut(16));
        fila.add(new JLabel("Monto :"));
        fila.add(lblMonto);
        return fila;
    }

    private JButton crearBtnContador(String texto) {
        JButton btn = new JButton(texto);
        btn.setPreferredSize(new Dimension(30, 28));
        btn.setFont(new Font("SansSerif", Font.PLAIN, 16));
        btn.setMargin(new Insets(0, 0, 0, 0));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void cambiarPersonas(int delta) {
        personas = Math.max(1, personas + delta);
        lblPersonas.setText(String.valueOf(personas));
        lblMonto.setText(calcularMonto());
    }

    private String calcularMonto() {
        int base = pedido.getMonto() > 0 ? pedido.getMonto() : PRECIO_BASE;
        return (base * personas) + " pesos";
    }

    private JPanel crearFilaArea() {
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        fila.setOpaque(false);
        txtArea = new JTextField(22);
        txtArea.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtArea.setToolTipText("Ej. Terraza, Interior, VIP...");
        fila.add(new JLabel("Área:"));
        fila.add(txtArea);
        return fila;
    }

    private JPanel crearFilaOtraPersona() {
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        fila.setOpaque(false);
        JLabel lbl = new JLabel("Desea reservar para otra persona");
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 15));
        fila.add(lbl);
        fila.add(crearBoton("Reservar", e -> onOtraPersona()));
        return fila;
    }

    private JButton crearBoton(String texto, java.awt.event.ActionListener accion) {
        JButton btn = new JButton(texto);
        btn.setBackground(NARANJA);
        btn.setForeground(Color.WHITE);
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFont(new Font("SansSerif", Font.PLAIN, 14));
        btn.setPreferredSize(new Dimension(140, 38));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addActionListener(accion);
        return btn;
    }

    // ── Acciones ──────────────────────────────────────────────
    private void onSiguiente() {
        Reservacion res = new Reservacion(restaurante);
        res.setFecha(lblFecha.getText());
        res.setPersonas(personas);
        res.setArea(txtArea.getText().trim());
        res.setMonto(Integer.parseInt(calcularMonto().replace(" pesos", "")));

        // Mostrar resumen
        String resumen = String.format(
            "Restaurante: %s%nProducto: %s%nFecha: %s%nPersonas: %d%nMonto: %s%nÁrea: %s",
            res.getRestaurante(), pedido.getNombreProducto(),
            res.getFecha(), res.getPersonas(),
            calcularMonto(),
            res.getArea().isEmpty() ? "Sin especificar" : res.getArea()
        );
        int op = JOptionPane.showConfirmDialog(
            this, resumen, "Confirmar reservación",
            JOptionPane.OK_CANCEL_OPTION, JOptionPane.INFORMATION_MESSAGE
        );
        if (op == JOptionPane.OK_OPTION) {
            JOptionPane.showMessageDialog(this, "¡Reservación confirmada!");
            ListaRestaurantes lr = new ListaRestaurantes("Carlos G");
            Navegador.ir(lr);
        }
    }

    private void onOtraPersona() {
        JOptionPane.showMessageDialog(this,
            "Pantalla 'Reservar para otra persona' próximamente.");
    }
}
